<?php

require_once(__ROOT__ . "controller/Controller.php");

class CompanyController extends Controller
{
	public function Con_addCompany()
	{
		$CompanyName=$_REQUEST['CompanyName'];
		$email=$_REQUEST['email'];
		$phoneNumber=$_REQUEST['phoneNumber'];
		$RegisterSupplierNumber=$_REQUEST['RegisterSupplierNumber'];
		$CommercialRecord=$_REQUEST['CommercialRecord'];

		//validation
		if(empty($_POST['CompanyName']) || empty($_POST['email'])|| empty($_POST['phoneNumber'])||empty($_POST['RegisterSupplierNumber'])||empty($_POST['CommercialRecord']))	
	    {
		 echo "<script>alert('Please Fill The empty space');
		 </script>";
	    }
		else
		$this->model->addcompany($CompanyName, $email, $phoneNumber, $RegisterSupplierNumber, $CommercialRecord);
	}

	public function Con_edit()
	{
		$CompanyName = $_REQUEST['CompanyName'];
		$email = $_REQUEST['email'];
        $phoneNumber = $_REQUEST['phoneNumber'];
		$RegisterSupplierNumber = $_REQUEST['RegisterSupplierNumber'];
		$CommercialRecord = $_REQUEST['CommercialRecord'];

		//validation
		if(empty($_POST['CompanyName']) || empty($_POST['email'])|| empty($_POST['phoneNumber'])||empty($_POST['RegisterSupplierNumber'])||empty($_POST['CommercialRecord']))	
	    {
		 echo "<script>alert('Please Fill The empty space');
		 </script>";
	    }
	    else
		$this->model->Model_editCompany($CompanyName, $email, $phoneNumber,$RegisterSupplierNumber, $CommercialRecord);
	}

	public function Con_delete()
	{
		if(empty($_POST['CompanyName']) || empty($_POST['email'])|| empty($_POST['phoneNumber'])||empty($_POST['RegisterSupplierNumber'])||empty($_POST['CommercialRecord']))	
	    {
		 echo "<script>alert('There is nothing to delete');
		 </script>";
	    }
	    else
		$this->deleteCompany();
	}
}
?>