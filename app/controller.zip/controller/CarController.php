<?php

require_once(__ROOT__ . "controller/Controller.php");

class CarController extends Controller
{	
	public function Con_addCar()
	{
		$CarName=$_REQUEST['CarName'];
		$CarModel=$_REQUEST['CarModel'];
		$CarYear=$_REQUEST['CarYear'];
		$imgName=$_REQUEST['imgName'];


		//validation
		if(empty($_POST['CarName']) || empty($_POST['CarModel'])|| empty($_POST['CarYear']))	
	    {
		 echo "<script>alert('Please Fill The empty space');
		 </script>";
	    }
	    else
		$this->model->addcar($CarName, $CarModel,$CarYear,$imgName);
		
	}
	public function editCar($CarID)
	 {
	 	$CarName = $_REQUEST['CarName'];
		$CarModel = $_REQUEST['CarModel'];
		$CarYear = $_REQUEST['CarYear'];

		//validation
		if(empty($_POST['CarName']) || empty($_POST['CarModel'])|| empty($_POST['CarYear']))	
	    {
		 echo "<script>alert('Please Fill The empty space');
		 </script>";
	    }
	    else
		$this->model->getCar($CarID)->Model_editCar($CarName,$CarModel,$CarYear);
	}

	public function delete($CarID)
	{
		if(empty($_POST['CarName']) || empty($_POST['CarModel'])|| empty($_POST['CarYear']))	
	    {
		 echo "<script>alert('No Car to delete');
		 </script>";
	    }
	    else
		$this->model->getCar($CarID)->deleteCar();
	}
}
?>