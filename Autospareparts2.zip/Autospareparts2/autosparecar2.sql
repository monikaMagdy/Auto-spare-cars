-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2020 at 11:00 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autosparecar`
--

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

CREATE TABLE `car` (
  `CarID` int(255) NOT NULL,
  `CarName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `car`
--

INSERT INTO `car` (`CarID`, `CarName`) VALUES
(1, 'Scania\r\n'),
(2, 'IVECO'),
(3, 'MAN');

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE `checkout` (
  `ID` int(255) NOT NULL,
  `CarName` varchar(255) NOT NULL,
  `partName` varchar(255) NOT NULL,
  `PartNumber` int(255) NOT NULL,
  `price` int(255) NOT NULL,
  `Quantity` int(255) NOT NULL,
  `totalPrice` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `export`
--

CREATE TABLE `export` (
  `ExportID` int(255) NOT NULL,
  `TotalCost` int(255) NOT NULL,
  `CarID` int(255) NOT NULL,
  `PartNumber` int(255) NOT NULL,
  `LocalCompanyID` int(255) NOT NULL,
  `Quantity` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `export`
--

INSERT INTO `export` (`ExportID`, `TotalCost`, `CarID`, `PartNumber`, `LocalCompanyID`, `Quantity`) VALUES
(3, 74, 3, 1071285, 2, 400),
(4, 74, 3, 1071285, 2, 400);

-- --------------------------------------------------------

--
-- Table structure for table `import`
--

CREATE TABLE `import` (
  `ImportID` int(255) NOT NULL,
  `TotalCost` int(255) NOT NULL,
  `CarID` int(255) NOT NULL,
  `PartNumber` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `largecompany`
--

CREATE TABLE `largecompany` (
  `InternationalCompanyID` int(255) NOT NULL,
  `ImportID` int(255) NOT NULL,
  `PartNumber` int(255) NOT NULL,
  `CompanyName` varchar(255) NOT NULL,
  `CompanyAddress` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `localcompany`
--

CREATE TABLE `localcompany` (
  `LocalCompanyID` int(255) NOT NULL,
  `CompanyName` varchar(255) NOT NULL,
  `ComanyAddress` varchar(255) NOT NULL,
  `RegisterSupplierNumber` int(255) NOT NULL,
  `CommercialRecord` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `localcompany`
--

INSERT INTO `localcompany` (`LocalCompanyID`, `CompanyName`, `ComanyAddress`, `RegisterSupplierNumber`, `CommercialRecord`) VALUES
(1, 'petroget', 'djhbc', 123456789, '098765432'),
(2, 'petroget', 'djhbc', 123456789, '098765432');

-- --------------------------------------------------------

--
-- Table structure for table `sparepart`
--

CREATE TABLE `sparepart` (
  `PartNumber` int(255) NOT NULL,
  `PartName` varchar(255) NOT NULL,
  `CarID` int(255) NOT NULL,
  `CarName` varchar(255) NOT NULL,
  `partCountry` varchar(255) NOT NULL,
  `partPrice` int(11) NOT NULL,
  `partQuantity` int(30) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sparepart`
--

INSERT INTO `sparepart` (`PartNumber`, `PartName`, `CarID`, `CarName`, `partCountry`, `partPrice`, `partQuantity`, `image`) VALUES
(1071285, 'Piston', 3, 'Man', 'Germany', 100, 1000, '6.jpg'),
(2060821, 'Fuel filter', 1, 'Scania', 'Turkey', 100, 1000, '1.jpg\r\n'),
(2995665, 'Sebaka', 2, 'Iveco', 'Italy', 100, 1000, '3.jpg'),
(4897481, 'Tube oil pump', 2, 'Iveco', 'Italy', 100, 1000, '4.jpg'),
(5061228, 'Piston', 1, 'Scania', 'Germany', 100, 10000, '2.jpg'),
(5672145, 'Tube water pump', 3, 'MAN', 'Germany', 100, 10000, '5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(255) NOT NULL,
  `UserFirstName` varchar(255) NOT NULL,
  `UserLastName` varchar(255) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `ExportID` int(11) NOT NULL,
  `ImoprtID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`CarID`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `export`
--
ALTER TABLE `export`
  ADD PRIMARY KEY (`ExportID`),
  ADD KEY `PartNumber` (`PartNumber`),
  ADD KEY `LocalCompanyID` (`LocalCompanyID`),
  ADD KEY `CarID` (`CarID`);

--
-- Indexes for table `import`
--
ALTER TABLE `import`
  ADD PRIMARY KEY (`ImportID`),
  ADD KEY `PartNumber` (`PartNumber`),
  ADD KEY `CarID` (`CarID`);

--
-- Indexes for table `largecompany`
--
ALTER TABLE `largecompany`
  ADD PRIMARY KEY (`InternationalCompanyID`),
  ADD KEY `ImportID` (`ImportID`),
  ADD KEY `PartNumber` (`PartNumber`);

--
-- Indexes for table `localcompany`
--
ALTER TABLE `localcompany`
  ADD PRIMARY KEY (`LocalCompanyID`);

--
-- Indexes for table `sparepart`
--
ALTER TABLE `sparepart`
  ADD PRIMARY KEY (`PartNumber`),
  ADD KEY `CarID` (`CarID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`),
  ADD KEY `ExportID` (`ExportID`),
  ADD KEY `ImoprtID` (`ImoprtID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `car`
--
ALTER TABLE `car`
  MODIFY `CarID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `checkout`
--
ALTER TABLE `checkout`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `export`
--
ALTER TABLE `export`
  MODIFY `ExportID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `import`
--
ALTER TABLE `import`
  MODIFY `ImportID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `largecompany`
--
ALTER TABLE `largecompany`
  MODIFY `InternationalCompanyID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `localcompany`
--
ALTER TABLE `localcompany`
  MODIFY `LocalCompanyID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sparepart`
--
ALTER TABLE `sparepart`
  MODIFY `PartNumber` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5672146;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `export`
--
ALTER TABLE `export`
  ADD CONSTRAINT `export_ibfk_1` FOREIGN KEY (`PartNumber`) REFERENCES `sparepart` (`PartNumber`),
  ADD CONSTRAINT `export_ibfk_2` FOREIGN KEY (`LocalCompanyID`) REFERENCES `localcompany` (`LocalCompanyID`),
  ADD CONSTRAINT `export_ibfk_3` FOREIGN KEY (`CarID`) REFERENCES `car` (`CarID`);

--
-- Constraints for table `import`
--
ALTER TABLE `import`
  ADD CONSTRAINT `import_ibfk_1` FOREIGN KEY (`PartNumber`) REFERENCES `sparepart` (`PartNumber`),
  ADD CONSTRAINT `import_ibfk_2` FOREIGN KEY (`CarID`) REFERENCES `car` (`CarID`);

--
-- Constraints for table `largecompany`
--
ALTER TABLE `largecompany`
  ADD CONSTRAINT `largecompany_ibfk_1` FOREIGN KEY (`ImportID`) REFERENCES `import` (`ImportID`),
  ADD CONSTRAINT `largecompany_ibfk_2` FOREIGN KEY (`PartNumber`) REFERENCES `sparepart` (`PartNumber`);

--
-- Constraints for table `sparepart`
--
ALTER TABLE `sparepart`
  ADD CONSTRAINT `sparepart_ibfk_1` FOREIGN KEY (`CarID`) REFERENCES `car` (`CarID`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`ExportID`) REFERENCES `export` (`ExportID`),
  ADD CONSTRAINT `user_ibfk_2` FOREIGN KEY (`ImoprtID`) REFERENCES `import` (`ImportID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
